<span class="controlIcons">
    <span class="icon check" id="check{{$model->id}}" data-id="{{$model->id}}" data-bs-toggle="tooltip" title="Check"> <i class="fal fa-check"></i> </span>
</span>
