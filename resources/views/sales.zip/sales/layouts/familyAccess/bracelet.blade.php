
<input type="text" id="braceletNumber{{$model->id}}" data-id="{{$model->id}}" class="form-control braceletNumbers" placeholder="Bracelet Number">
