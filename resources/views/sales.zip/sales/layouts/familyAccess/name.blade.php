<input type="text" class="form-control names" name="names" id="name{{$model->id}}" placeholder="Name" disabled value="{{$model->name}}">
