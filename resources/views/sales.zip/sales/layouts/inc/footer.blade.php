<footer id="loadFooter" class="footer pt-3">
    <div class="container-fluid">
        <div class="row align-items-center justify-content-lg-between">
            <div class="col-lg-6 mb-lg-0 mb-4">
                <div class="copyright text-center text-sm text-muted text-lg-start">
                    ©
                     {{date('Y')}}
                    made with <i class="fa fa-heart mx-1"></i> by
                    <a href="http://motaweron.com/index.html" class="font-weight-bold" target="_blank">Elmotweron</a></div>
            </div>
        </div>
    </div>
</footer>


