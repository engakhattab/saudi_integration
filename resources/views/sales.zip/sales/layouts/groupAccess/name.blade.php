<input type="text" class="form-control names" name="names" id="name{{$model->id}}" placeholder="Name" value="{{$model->name}}" disabled>
