<div class="day getData toDay">
    <span class="num"> <?php echo $i ;?></span>
    <div class="capacityContainer">
        <div class="capacityPercentage" style="width: 60%;">
        </div>
    </div>
    <div class="events">
        <div class="event"> <span class="icon"> <i class="fad fa-bus-school"></i> </span></div>
        <div class="event"> <span class="icon"> <i class="fas fa-fire-alt"></i> </span></div>
        <div class="event"> <span class="icon"> <i class="fas fa-birthday-cake"></i> </span></div>
        <div class="event"> <span class="icon"> <i class="fas fa-city"></i> </span></div>

    </div>
</div>
